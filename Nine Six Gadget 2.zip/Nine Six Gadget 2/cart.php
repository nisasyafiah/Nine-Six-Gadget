<?php
include('config.php');
include('common_function.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NINE SIX GADGET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" href="style3.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>

    <style>
      .gradient-custom {
  /* fallback for old browsers */
  background: #202020;
  
  /* Chrome 10-25, Safari 5.1-6 */
  background: -webkit-linear-gradient(to right, rgb(0, 0, 0), rgb(98, 99, 99));
  
  /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
  background: linear-gradient(to right, rgb(0, 0, 0), rgb(95, 96, 97))
  }
    </style>
  </head>
<body class="h-100 gradient-custom">

  <div class="container py-5">
   <div class="row d-flex justify-content-center my-4">
          <div class="col-md-8">
<div class="card mb-4">
  <div class="card-header py-3">
    <h5 class="mb-0">Troli</h5>
    <form action="" method="POST">
      <?php
          global $con;
          $get_ip_add=getIPAddress();
          $total_price=0;
          $cart_query="Select * from `butiran_troli` where ip_address='$get_ip_add'";
          $result=mysqli_query($con,$cart_query);
          $result_count=mysqli_num_rows($result);
          if($result_count>0){

          while($row=mysqli_fetch_array($result)){
            $id_produk=$row['id_produk'];
            $select_products="Select*from `produk` where id_produk='$id_produk'";
            $result_products=mysqli_query($con,$select_products);
            while($row_product_price=mysqli_fetch_array($result_products)){
              $harga_produk=array($row_product_price['harga_produk']);
              $price_table=$row_product_price['harga_produk'];
              $nama_produk=$row_product_price['nama_produk'];
              $ulasan_produk=$row_product_price['ulasan_produk'];
              $gambar_produk=$row_product_price['gambar_produk'];
              $product_values=array_sum($harga_produk);
              $total_price+=$product_values;
        ?>
            
          </div>
             <div class="card-body">
            <!-- Single item -->
            <div class="row">
              <div class="col-lg-3 col-md-12 mb-4 mb-lg-0">
             <div class="bg-image hover-overlay hover-zoom ripple rounded" data-mdb-ripple-color="light">
                <img src="./gambar_produkk/<?php echo "$gambar_produk";?>"
                    class="w-100" alt="Blue Jeans Jacket" />
                  <a href="#!">
                    <div class="mask" style="background-color: rgba(251, 251, 251, 0.2)"></div>
                  </a>
                </div>
                <!-- Image -->
              </div>

              <div class="col-lg-5 col-md-6 mb-4 mb-lg-0">
                <!-- Data -->
                <p><strong><?php echo $nama_produk ?></strong></p>
                <p><?php echo $ulasan_produk ?></p>
               <center><p class="text-start text-md-center"></center>
                  Harga: <?php echo $price_table?>
                </p>
                <!-- Data -->
              </div>

              <div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
                

                <!-- Price -->
                <div class="col-md-6 mb-4 mb-lg-0">
    <div class="form-check">
        <input type="checkbox" name="removeitem[]" value="<?php echo $id_produk ?>" class="form-check-input">
        <label class="form-check-label">
            Item <?php echo $id_produk; ?>
        </label>
    </div>
    <button type="submit" class="btn btn-primary btn-sm me-1 mt-2" data-mdb-toggle="tooltip" title="Remove item" name="remove_cart">
        Keluarkan Item
    </button>
</div>

                <!-- Price -->
              </div>
            </div>




<?php
}
}
          }
          else{
            echo "<h2>Oopss troli anda kosong!</h2>";
          }
?>

        <!--<div class="card mb-4 mb-lg-0">
          <div class="card-body">
            <p><strong>We accept</strong></p>
            <img class="me-2" width="45px"
              src="https://mdbcdn.b-cdn.net/wp-content/plugins/woocommerce-gateway-stripe/assets/images/visa.svg"
              alt="Visa" />
            <img class="me-2" width="45px"
              src="https://mdbcdn.b-cdn.net/wp-content/plugins/woocommerce-gateway-stripe/assets/images/amex.svg"
              alt="American Express" />
            <img class="me-2" width="45px"
              src="https://mdbcdn.b-cdn.net/wp-content/plugins/woocommerce-gateway-stripe/assets/images/mastercard.svg"
              alt="Mastercard" />
            <img class="me-2" width="45px"
              src="https://mdbcdn.b-cdn.net/wp-content/plugins/woocommerce/includes/gateways/paypal/assets/images/paypal.webp"
              alt="PayPal acceptance mark" />
          </div>
        </div>-->
      
     <br>
     <div class="card mb-4">
    <div class="card-header py-3">
        <h5 class="mb-0">Ringkasan</h5>
    </div>
    <div class="card-body">
        <ul class="list-group list-group-flush">
            <li class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 mb-3">
                <div class="ms-auto me-2">
                    <strong>JUMLAH: RM <?php echo $total_price ?></strong>
                    <br><br>
                    <a href="payment.php" class="btn btn-primary">
                        <i class="fa fa-shopping-bag me-2"></i>Beli Sekarang
                    </a>
                </div>
            </li>
        </ul>

        <div class="mt-3">
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-angle-left me-2"></i>Kembali Membeli Belah
            </a>
        </div>
    </div>
</div>

          </div>
        </div>
      </div>
    </div>
  </div>
</form>

<?php
function remove_cart_item() {
  global $con;
  if (isset($_POST['remove_cart'])) {
    foreach ($_POST['removeitem'] as $remove_id) {
      echo $remove_id;
      $delete_query = "DELETE FROM `butiran_troli` WHERE id_produk = $remove_id";
      $run_delete = mysqli_query($con, $delete_query);
      if ($run_delete) {
        echo "<script>window.open('cart.php','_self')</script>";
      }
    }
  }
}
remove_cart_item();
?>



</body>
</html>
