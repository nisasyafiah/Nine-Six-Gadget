<?php
include('config.php');
if (isset($_POST['tambah_produk'])) {

    $nama_produk = $_POST["nama_produk"];
    $ulasan_produk = $_POST["ulasan_produk"];
    $katakunci_produk = $_POST["katakunci_produk"];
    $kategori_produk = $_POST["kategori_produk"];
    $gambar_produk = $_FILES["gambar_produk"]["name"];
    $harga_produk = $_POST["harga_produk"];
    $status_produk = 'true';

    $target = "gambar_produk/" . basename($gambar_produk);
    $add = mysqli_query($con, "INSERT INTO produk(nama_produk, ulasan_produk, katakunci_produk, kategori_produk, gambar_produk, harga_produk, status_produk) VALUES ('$nama_produk','$ulasan_produk','$katakunci_produk','$kategori_produk','$gambar_produk','$harga_produk','$status_produk')");
    if ($add) {
        echo "<script>alert('Category')</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NINE SIX GADGET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
        crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
        crossorigin="anonymous"></script>
    <style>
        .gradient-custom {
            /* fallback for old browsers */
            background: #202020;

            /* Chrome 10-25, Safari 5.1-6 */
            background: -webkit-linear-gradient(to right, rgb(0, 0, 0), rgb(98, 99, 99));

            /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
            background: linear-gradient(to right, rgb(0, 0, 0), rgb(95, 96, 97))
        }

        /* Make all text white */
        body,
        label,
        .btn,
        .form-control {
            color: white;
        }
    </style>
</head>

<body class="h-100 gradient-custom">
    <br>
    <div class="mx-auto" style="width: 20%;">
        <img src="NSG_Logo.png" class="rounded" alt="..." width="100%">
    </div>
    <br>
    <h1 class="text-center text-white">Tambah Produk</h1>
    <br>
    <!--form-->
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-outline mb-4 w-50 m-auto">
            <label for="nama_produk" class="form-label">Nama Produk</label>
            <input type="text" name="nama_produk" id="nama_produk" class="form-control"
                placeholder="Masukkan Nama Produk" required="required">
        </div>

        <div class="form-outline mb-4 w-50 m-auto">
            <label for="ulasan_produk" class="form-label">Ulasan Produk</label>
            <input type="text" name="ulasan_produk" id="ulasan_produk" class="form-control"
                placeholder="Masukkan Ulasan Produk" required="required">
        </div>

        <div class="form-outline mb-4 w-50 m-auto">
            <label for="katakunci_produk" class="form-label">Katakunci Produk</label>
            <input type="text" name="katakunci_produk" id="katakunci_produk" class="form-control"
                placeholder="Masukkan Katakunci Produk" required="required">
        </div>

        <div class="form-outline mb-4 w-50 m-auto">
            <label for="kategori_produk" class="form-label">Kategori Produk</label>
            <select name="kategori_produk" id="" class="form-select">
                <option value="">Pilih Kategori Produk</option>
                <option value="headphone">Headphone</option>
                <option value="earphone">Earphone</option>
                <option value="earbud">Earbud</option>
                <option value="wireless">Wireless</option>
                <option value="wired">Wired</option>
                <option value="type-c">Type-C</option>
                <option value="micro">Micro</option>
                <option value="iphone">Iphone</option>
                <option value="charger">Charger</option>
            </select>
        </div>

        <div class="form-outline mb-4 w-50 m-auto">
            <label for="gambar_produk" class="form-label">Gambar Produk</label>
            <input type="file" name="gambar_produk" id="gambar_produk" class="form-control"
                placeholder="Masukkan Nama Produk" required="required">
        </div>

        <div class="form-outline mb-4 w-50 m-auto">
            <label for="harga_produk" class="form-label">Harga Produk</label>
            <input type="text" name="harga_produk" id="harga_produk" class="form-control"
                placeholder="Masukkan Harga Produk" required="required">
        </div>

        <div class="form-outline mb-4 w-50 m-auto">
            <input type="submit" name="tambah_produk" class="btn btn-primary mb-3 px-3" value="Tambah Produk">
        </div>

    </form>
    </div>
</body>

</html>
