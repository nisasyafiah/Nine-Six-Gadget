<?php
include('config.php');
include('common_function.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NINE SIX GADGET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" href="style2.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <style>
        .gradient-custom {
  /* fallback for old browsers */
  background: #000000;
  }

  .gradient-navbar {
  /* fallback for old browsers */
  background: #c20000;
  }

  .navbarhover a:hover, .dropdown:hover{
    background-color: #810000;
}
.dropdown-content:hover{
    background-color: #E8F9FD;
}

.dropdown-content{
    background-color: #FBF9F1;
}
.dropdown-menu{
    background-color: #FBF9F1;
}
    </style>
  </head>
<body>
<nav class="navbar navbar-expand-lg bg-body-black header gradient-navbar">
  <div class="container-fluid">
  <a class="navbar-brand" href="#">
      <img src="NSG_Logo.png" alt="Nine Six Gadget" width="100" height="100">
    </a>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0 mx-auto px-auto gap-5">
      <li class="nav-item navbarhover">
          <a class="nav-link active text-white" aria-current="page" href="index.php">UTAMA</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            FON KEPALA
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item dropdown-content" href="headphone.php">Fon Kepala</a></li>
            <li><a class="dropdown-item dropdown-content" href="earphone.php">Fon Telinga Berwayar</a></li>
            <li><a class="dropdown-item dropdown-content" href="earbud.php">Fon Telinga Tanpa Wayar</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            PEMBESAR SUARA
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item dropdown-content" href="wireless.php">Tanpa Wayar</a></li>
            <li><a class="dropdown-item dropdown-content" href="wired.php">Berwayar</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            KABEL & PENGECAS
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item dropdown-content" href="micro.php">Kabel Mikro</a></li>
            <li><a class="dropdown-item dropdown-content" href="typec.php">Kabel Type-C</a></li>
            <li><a class="dropdown-item dropdown-content" href="iphone.php">Kabel Iphone</a></li>
            <li><a class="dropdown-item dropdown-content" href="charger.php">Pengecas</a></li>
          </ul>
        </li>
      </ul>

      <?php
      if(!isset($_SESSION['nama_pengguna'])){
        echo" <a class='nav-link text-white' href='#'>Hai! Selamat Datang Pengguna</a>";

      }else{
        echo"  <a class='nav-link text-white' href='#'>Hi! Selamat Datang ".$_SESSION['nama_pengguna']."!</a>";
      }   
      ?>

      <div class="nav-item cart text-white ps-5 pe-1">
        <a class="nav-link" href="cart.php"><i class="fa fa-shopping-cart"></i><sup><?php cart_item();?></sup></a>
      </div>

      <div class="cart">
      <div class="nav-item text-white pe-5 ps-5">
        <a class="nav-link" href="user_login.php"><i class="fa fa-user"></i></a>
      </div>
</div>
<!--calling cart function-->
<?php
cart();
?>
    </div>
  </div>
</div>
</nav>

<section class="h-100 gradient-custom">
  <br>
<h1 class="text-center text-white">Pembesar Suara Berwayar</h1>
<!--products-->
<div class="row mx-auto p-5">
  
<!--calling function-->
<?php
getwired();
//$ip = getIPAddress();  
//echo 'User Real IP Address - '.$ip;  
?>
</div>
    </div>
    </div>
</div>
    </div>
    </div>
</div>
<!-- Footer -->
<footer class="text-center text-lg-start bg-body-tertiary text-muted">
  <section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
    <div class="me-5 d-none d-lg-block">
      <span>Ikuti kami di: </span>
    </div>
    <div>
      <a href="https://www.facebook.com/p/Nine-Six-Gadgets-100063756921899/" class="me-4 text-reset"><i class="fab fa-facebook-f"></i></a>
      <a href="https://www.google.com/search?client=opera&q=nine+six+gadgets&sourceid=opera&ie=UTF-8&oe=UTF-8#ip=1" class="me-4 text-reset"><i class="fab fa-google"></i></a>
      <a href="#" class="me-4 text-reset"><i class="fab fa-instagram"></i></a>
    </div>
  </section>
  <section class="mb-4">
  <div class="container text-center text-md-start">
    <div class="row mt-3">
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
        <h6 class="text-uppercase fw-bold mb-4"><i class="fas fa-map-pin me-3"></i>Nine Six Gadget</h6>
        <p>Phone Repair, Accesories. </p>
      </div>
      <div class="col-md-6 col-lg-4 col-xl-2 mx-auto mb-4">
        <h6 class="text-uppercase fw-bold mb-4"><i class="fas fa-clock me-3"></i>Masa Operasi</h6>
        <table class="table">
  <tr>
    <td>Isnin</td>
    <td>11 a.m–10 p.m</td>
  </tr>
  <tr>
    <td>Selasa</td>
    <td>11 a.m–10 p.m</td>
  </tr>
  <tr>
    <td>Rabu</td>
    <td>11 a.m–10 p.m</td>
  </tr>
  <tr>
    <td>Khamis</td>
    <td>11 a.m–10 p.m</td>
  </tr>
  <tr>
    <td>Jumaat</td>
    <td>11 a.m–10 p.m</td>
  </tr>
  <tr>
    <td>Sabtu</td>
    <td>11 a.m–10 p.m</td>
  </tr>
  <tr>
    <td>Ahad</td>
    <td>11 a.m–10 p.m</td>
  </tr>
</table>


      </div>
      <div class="col-md-3 col-lg-2 col-xl-3 mx-auto mb-4">
      <h6 class="text-uppercase fw-bold mb-4"><i class="fas fa-map-location-dot me-3"></i>Lokasi Kami</h6>
        <div class="embed-responsive embed-responsive-16by9">
          <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3983.1177588724354!2d101.26892807474447!3d3.3210656966537715!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31ccf58c2adee7ed%3A0xc4c8a9478576fb6d!2sNine%20Six%20Gadgets!5e0!3m2!1sen!2smy!4v1703788465148!5m2!1sen!2smy" allowfullscreen></iframe>
        </div>
      </div>
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
        <h6 class="text-uppercase fw-bold mb-4"><i class="fas fa-address-card me-3"></i>Tentang Kami</h6>
        <p><i class="fas fa-home me-3"></i>No 2A, Jalan Medan Niaga, 5, Medan Niaga, 45000 Kuala Selangor, Selangor</p>
        <p><i class="fas fa-phone me-3"></i> + 018-669 9182</p>

      </div>
    </div>
  </div>
</section>

  <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
    © 2023 Copyright: <a class="text-reset fw-bold" href="https://ninesixgadget.com/">NineSixGadget.com</a>
  </div>
</footer>



<!-- Footer -->
</body>
</html>