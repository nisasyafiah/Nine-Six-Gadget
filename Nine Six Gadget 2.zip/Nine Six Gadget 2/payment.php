<?php
include('config.php');
include('common_function.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NINE SIX GADGET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style3.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <style>
      .gradient-custom {
  /* fallback for old browsers */
  background: #202020;
  
  /* Chrome 10-25, Safari 5.1-6 */
  background: -webkit-linear-gradient(to right, rgb(0, 0, 0), rgb(98, 99, 99));
  
  /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
  background: linear-gradient(to right, rgb(0, 0, 0), rgb(95, 96, 97))
  }
    </style>
</head>
<body  class="h-100 gradient-custom">
<div class="container py-5">
   <div class="row d-flex justify-content-center my-4">
          <div class="col-md-8">
          <div class="card mb-4">
  <div class="card-header py-3">
    <h5 class="mb-0">Troli</h5>
<form action="payment_generate.php" method="POST">

    <?php
    global $con;
    $get_ip_add = getIPAddress();
    $calctotal = 0;
    $cart_query = "SELECT * FROM `butiran_troli` WHERE ip_address='$get_ip_add'";
    $result = mysqli_query($con, $cart_query);
    $result_count = mysqli_num_rows($result);
    if ($result_count > 0) {
        while ($row = mysqli_fetch_array($result)) {
            $id_produk = $row['id_produk'];
            $select_products = "SELECT * FROM `produk` WHERE id_produk='$id_produk'";
            $result_products = mysqli_query($con, $select_products);

            while ($row_product = mysqli_fetch_assoc($result_products)) {
                $id_produk = $row_product['id_produk'];
                $gambar_produk = $row_product['gambar_produk'];
                $ulasan_produk = $row_product['ulasan_produk'];
                $harga_produk = $row_product['harga_produk'];
                $nama_produk = $row_product['nama_produk'];

               ?>
                <div class="card-body">
            <!-- Single item -->
            <div class="row">
              <div class="col-lg-3 col-md-12 mb-4 mb-lg-0">
                
             <div class="bg-image hover-overlay hover-zoom ripple rounded" data-mdb-ripple-color="light">
                <img src="./gambar_produkk/<?php echo "$gambar_produk";?>"
                    class="w-100" alt="Blue Jeans Jacket" />
                  <a href="#!">
                    <div class="mask" style="background-color: rgba(251, 251, 251, 0.2)"></div>
                  </a>
                </div>
                <!-- Image -->
              </div>

              <div class="col-lg-5 col-md-6 mb-4 mb-lg-0">
                <!-- Data -->
                <p><strong><?php echo $nama_produk ?></strong></p>
                <p><?php echo $ulasan_produk ?></p>
                <p>RM <?php echo $harga_produk ?></p>
                <?php
               echo" <input type='checkbox' name='id_produk[]' value='$id_produk'
                        onclick='calctotal($harga_produk, this.checked)' 
                        class='checks' data-harga_produk='$harga_produk'> pilih barang";
                ?>

                <!-- Data -->
              </div>

              <div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
                

                <!-- Price -->
                
                <!-- Price -->
              </div>
            </div>
               <?php
            }
        }
    } else {
        echo "No results";
    }
    ?>

<?php
$id_pengguna = 6;

// Fetch user information from the database
$user_query = "SELECT * FROM pengguna WHERE id_pengguna = $id_pengguna";
$user_result = mysqli_query($con, $user_query);
$user_data = mysqli_fetch_assoc($user_result);

// Check if user data is found
if ($user_data) {
    $nama_pengguna = $user_data['nama_pengguna'];
    $email_pengguna = $user_data['email_pengguna'];
    $notel_pengguna = $user_data['notel_pengguna'];
} else {
    // Handle the case when user data is not found
    // You can redirect or display an error message
    echo "User not found";
    exit;
}
?>
    <!-- javascript to calculate total price -->
    <script>
        var total = 0;

        function calctotal(harga_produk, togglecheck) {
            if (togglecheck == true) {
                total += harga_produk;
            } else {
                total -= harga_produk;
            }

            document.getElementById("totalprice").value = total.toFixed(2);
        }
    </script>
    <br>
    <div class="row">
        <div class="col-4">
            Jumlah Harga<br>
            <input type="text" name="totalprice" id="totalprice" readonly value="0.0" class="form-control">
        </div>

   
    </div>

    <div class="row">
        <div class="col-4">
            Nama<br>
            <input type="text" name="nama_pengguna" value="<?php echo $nama_pengguna; ?>" required class="form-control">
        </div>

        <div class="col-4">
            Emel<br>
            <input type="email" name="email_pengguna" value="<?php echo $email_pengguna; ?>" required class="form-control">
        </div>

        <div class="col-4">
            Nombor Telefon<br>
            <input type="tel" name="notel_pengguna" value="<?php echo $notel_pengguna; ?>" required class="form-control">
        </div>
    </div>

        <div class="col-4">
            &nbsp;<br>
            <button type="submit" class="btn btn-primary">
                Bayar Sekarang &gt;&gt;</button>
        </div>
    </div>
</form>

<?php
if (isset($_GET['error'])) {
    $error = $_GET['error'];
    echo "<div class='alert alert-warning'>$error</div>";
}
if (isset($_GET['success'])) {
    $success = $_GET['success'];
    echo "<div class='alert alert-success'>$success</div>";
}
?>
