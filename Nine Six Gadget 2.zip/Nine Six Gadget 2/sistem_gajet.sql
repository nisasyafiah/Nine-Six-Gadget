-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 29, 2024 at 04:28 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistem_gajet`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama_admin` varchar(255) NOT NULL,
  `katalaluan_admin` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama_admin`, `katalaluan_admin`) VALUES
(1, 'admin', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `butiran_troli`
--

CREATE TABLE `butiran_troli` (
  `id_produk` int(11) NOT NULL,
  `ip_address` varchar(255) NOT NULL,
  `kuantiti` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `butiran_troli`
--

INSERT INTO `butiran_troli` (`id_produk`, `ip_address`, `kuantiti`) VALUES
(6, '::1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_pengguna` int(11) NOT NULL,
  `nama_pengguna` varchar(100) NOT NULL,
  `email_pengguna` varchar(100) NOT NULL,
  `katalaluan_pengguna` varchar(255) NOT NULL,
  `ip_pengguna` varchar(100) NOT NULL,
  `notel_pengguna` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_pengguna`, `nama_pengguna`, `email_pengguna`, `katalaluan_pengguna`, `ip_pengguna`, `notel_pengguna`) VALUES
(6, 'itik gembo gembo', 'itikgembo@gmail.com', '$2y$10$Gm197u/359FA6f4RUjMQd.k80KD9sr2h3ygQoyOXGEARzbMYzpnrW', '::1', '011203987684827'),
(7, 'iman aqilah', 'nurimanaqilah7@gmail.com', '$2y$10$Msl8lvCoip4WsxcBJNMnCuhjgZamNHZN4GYP.pHocDTwritiV/SEa', '::1', '011-28042323'),
(8, 'nisa', 'nisasyaf47@gmail.com', '$2y$10$79RwNICeTHsfPlQKPQT82OF9PsD3ouLS75cj2TMJrWiGpcEBh6dXS', '::1', '01111398745');

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `ulasan_produk` varchar(255) NOT NULL,
  `katakunci_produk` varchar(255) NOT NULL,
  `kategori_produk` varchar(100) NOT NULL,
  `gambar_produk` varchar(255) NOT NULL,
  `harga_produk` varchar(100) NOT NULL,
  `tarikh` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status_produk` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `ulasan_produk`, `katakunci_produk`, `kategori_produk`, `gambar_produk`, `harga_produk`, `tarikh`, `status_produk`) VALUES
(1, 'JBL', 'Hitam ', 'earbud ', 'earbud', 'earbuds jbl 1.webp', '139.36', '2023-11-27 16:58:52', 'true'),
(2, 'JBL', 'Ungu ', 'earbud ', 'earbud', 'earbuds jbl 2.webp', '139.36', '2023-11-27 16:58:57', 'true'),
(3, 'JBL', 'Biru muda', 'earbud ', 'earbud', 'earbuds jbl 3.webp', '139.36', '2023-11-27 16:59:02', 'true'),
(4, 'JBL', '\r\n\r\nHijau pastel\r\n\r\n\r\n\r\n', 'earbud ', 'earbud', 'earbuds jbl 4.webp', '139.36', '2023-11-27 17:01:33', 'true'),
(5, 'Beats', 'Hitam ', 'headphone ', 'headphone', 'beats 1.jfif', '545.07', '2023-11-27 17:01:38', 'true'),
(6, 'Beats', 'Biru', 'headphone ', 'headphone', 'beats 2.jpg', '454.07', '2023-11-27 17:01:46', 'true'),
(7, 'Beats', 'Putih', 'headphone ', 'headphone', 'beats 3.jpg', '545.07', '2023-11-27 17:01:50', 'true'),
(8, 'Beats', 'Pink', 'headphone ', 'headphone', 'beats 4.jfif', '454.07', '2023-11-27 17:02:04', 'true'),
(9, 'JBL', 'Hitam ', 'headphone ', 'headphone', 'jbl 1.webp', '499.00', '2023-11-27 17:02:09', 'true'),
(10, 'JBL', 'Biru', 'headphone ', 'headphone', 'jbl 2.webp', '599.00', '2023-11-27 17:02:15', 'true'),
(11, 'JBL', 'Putih', 'headphone ', 'headphone', 'jbl 3.webp', '699.00', '2023-11-27 17:02:19', 'true'),
(12, 'JBL', 'Pink', 'headphone ', 'headphone', 'jbl 4.webp', '799.00', '2023-11-27 17:02:24', 'true'),
(13, 'Sony ', 'Hitam ', 'headphone ', 'headphone', 'sony 1.webp', '359.00', '2023-11-27 17:02:28', 'true'),
(14, 'Sony ', 'Biru', 'headphone ', 'headphone', 'sony 2.webp', '459.00', '2023-11-27 17:02:35', 'true'),
(15, 'Sony ', 'Putih', 'headphone ', 'headphone', 'sony 3.jpg', '559.00', '2023-11-27 17:02:40', 'true'),
(16, 'Sony ', 'Pink', 'headphone ', 'headphone', 'sony 4.jpg', '659.00', '2023-11-27 17:02:45', 'true'),
(17, 'Sony ', 'Biru', 'earbud ', 'earbud', 'earbuds sony 3.JPG', '91.00', '2023-11-27 17:02:49', 'true'),
(18, 'Sony ', 'Hijau', 'earbud ', 'earbud', 'earbuds sony 4.JPG', '91.00', '2023-11-27 17:05:19', 'true'),
(19, 'Sony ', 'Ungu', 'earbud ', 'earbud', 'earbuds sony 2.JPG', '91.00', '2023-11-27 17:05:22', 'true'),
(20, 'Sony ', 'Hitam', 'earbud ', 'earbud', 'earbuds sony 1.png', '91.00', '2023-11-28 14:46:16', 'true'),
(21, 'Redmi', 'Pink', 'earbud ', 'earbud', 'earbuds redmi 2.jfif', '100.00', '2023-11-27 17:05:32', 'true'),
(22, 'Redmi', 'Hitam ', 'earbud ', 'earbud', 'earbuds redmi 3.jfif', '100.00', '2023-11-27 17:05:36', 'true'),
(23, 'Redmi', 'Putih', 'earbud ', 'earbud', 'earbuds redmi 1.jfif', '100.00', '2023-11-27 17:05:39', 'true'),
(24, 'Redmi', 'Oren ', 'earbud ', 'earbud', 'earbuds redmi 4.jfif', '100.00', '2023-11-27 17:05:44', 'true'),
(25, 'JBL Xtreme 3', 'Kapasiti bateri:10,000mAh,warna hitam ', 'speaker ', 'wireless', 'speaker jbl 1(wireless).jpg', '349.75', '2023-11-27 17:05:48', 'true'),
(26, 'JBL Xtreme 3', 'Kapasiti bateri:10,000mAh,warna biru                                                                                                                                                           ', 'speaker ', 'wireless', 'speaker jbl 2(wireless).jpg', '349.75', '2023-11-27 17:05:52', 'true'),
(27, 'JBL Xtreme 3', 'Kapasiti bateri:10,000mAh,warna kelabu', 'speaker ', 'wireless', 'speaker jbl 3(wireless).JPG', '349.75', '2023-11-27 17:05:57', 'true'),
(28, 'JBL Charge 5  Portable  Speaker', 'Kapasiti bateri:7500mAh,warna hijau', 'speaker ', 'wireless', 'speaker jbl 4(wireless).JPG', '299.00', '2023-11-27 17:08:18', 'true'),
(29, 'Sony SRS-XB13', 'Kapasiti bateri:500mAh,warna biru cair', 'speaker ', 'wireless', 'speaker sony 1(wireless).jfif', '100', '2023-11-27 17:08:22', 'true'),
(30, 'Sony SRS-XB13', 'Kapasiti bateri:500mAh,warna hitam', 'speaker ', 'wireless', 'speaker sony 2(wireless).jfif', '100', '2023-11-27 17:08:29', 'true'),
(31, 'Sony SRS-XB13', 'Kapasiti bateri:500mAh,warna biru', 'speaker ', 'wireless', 'speaker sony 3(wireless).jfif', '100', '2023-11-27 17:08:26', 'true'),
(32, 'Sony SRS-XB13', 'Kapasiti bateri:500mAh,warna kelabu', 'speaker ', 'wireless', 'speaker sony 4(wireless).jfif', '100', '2023-11-27 17:08:33', 'true'),
(33, 'Lenovo LP5', 'Kelabu', 'earbud ', 'earbud', 'earbuds lenovo 1.jfif', '59.00', '2023-11-27 17:06:53', 'true'),
(34, 'Lenovo LP5', 'Putih', 'earbud ', 'earbud', 'earbuds lenovo 2.jfif', '59.00', '2023-11-27 17:06:57', 'true'),
(35, 'Lenovo Air Pro 6', 'Hitam ', 'earbud ', 'earbud', 'earbuds lenovo 3.jfif', '69.00', '2023-11-27 17:07:00', 'true'),
(36, 'Lenovo Air Pro 6', 'Putih ', 'earbud ', 'earbud', 'earbuds lenovo 4.jfif', '69.00', '2023-11-27 17:07:03', 'true'),
(37, 'Redragon H510 Zeus', 'Merah ', 'headphone ', 'headphone', 'headphone Redragon 1.webp', '200.00', '2023-11-27 17:07:07', 'true'),
(38, 'Redragon H510 Zeus', 'Putih', 'headphone ', 'headphone', 'headphone Redragon 2.webp', '200.00', '2023-11-27 17:07:11', 'true'),
(39, 'Redragon H510 Zeus', 'Ungu', 'headphone ', 'headphone', 'headphone Redragon 3.webp', '200.00', '2023-11-27 17:07:15', 'true'),
(40, 'Redragon H510 Zeus', 'Pink', 'headphone ', 'headphone', 'headphone Redragon 4.webp', '200.00', '2023-11-27 17:07:19', 'true'),
(41, 'Mini Vintage Speaker', 'Kapasiti Bateri:1200mAh,warna hitam,', 'speaker ', 'wireless', 'speaker vintage 1(wireless).jfif', '59.78', '2023-11-27 17:07:23', 'true'),
(42, 'Mini Vintage Speaker', 'Kapasiti Bateri:1200mAh,warna hijau', 'speaker ', 'wireless', 'speaker  vintage 2(wireless).jfif', '59.78', '2023-11-27 17:08:39', 'true'),
(43, 'Mini Vintage Speaker', 'Kapasiti Bateri : 1200mAh, warna pink\r\n', 'speaker ', 'wireless', 'speaker  vintage 3(wireless).jfif', '59.78', '2023-11-27 17:08:43', 'true'),
(44, 'Mini Vintage Speaker', 'Kapasiti Bateri: 1200mAh, warna merah', 'speaker ', 'wireless', 'speaker  vintage 4(wireless).jfif', '59.78', '2023-11-27 17:08:47', 'true'),
(45, 'Sanag X6s Speaker', 'Kapasiti Bateri: 1200mAh, warna ungu', 'speaker ', 'wireless', 'speaker sanag 1(wireless).jfif', '129.99', '2023-11-27 17:08:51', 'true'),
(46, 'Sanag X6s Speaker', 'Kapasiti bateri:500mAh,warna biru muda', 'speaker ', 'wireless', 'speaker sanag 2(wireless).jfif', '129.99', '2023-11-27 17:08:58', 'true'),
(47, 'Sanag X6s Speaker', 'Kapasiti Bateri: 1200mAh, warna pink', 'speaker ', 'wireless', 'speaker sanag 4(wireless).jfif', 'RM129.99', '2023-11-25 04:18:27', 'true'),
(48, 'Sanag X6s Speaker', 'Kapasiti Bateri:1200mAh,warna magenta', 'speaker ', 'wireless', 'speaker sanag 3(wireless).jfif', '129.99', '2023-11-27 17:09:02', 'true'),
(49, 'JBL T110', 'Hitam ', 'earphone', 'earphone', 'earphone jbl 1.jfif', '59.00', '2023-11-27 17:09:09', 'true'),
(50, 'JBL T110', 'Putih', 'earphone', 'earphone', 'earphone jbl 2.jfif', '59.00', '2023-11-27 17:09:13', 'true'),
(51, 'JBL T110', 'Biru', 'earphone', 'earphone', 'earphone jbl 3.jfif', '59.00', '2023-11-27 17:09:44', 'true'),
(52, 'JBL T110', 'Merah', 'earphone', 'earphone', 'earphone jbl 4.jfif', '59.00', '2023-11-27 17:09:50', 'true'),
(53, 'Awei PC-7T', 'Jenis : Type-c , warna hitam ', 'earphone', 'earphone', 'earphone awei 1.jfif', '53.11', '2023-11-27 17:09:53', 'true'),
(54, 'Awei PC-7T', 'Jenis : Type-c , warna putih', 'earphone', 'earphone', 'earphone awei 2.jfif', '53.11', '2023-11-27 17:10:00', 'true'),
(55, 'Awei PC-7', 'Jenis: Micro, warna hitam ', 'earphone', 'earphone', 'earphone awei 3.jfif', '13.98', '2023-11-27 17:10:04', 'true'),
(56, 'Awei PC-7', 'Jenis: Micro, warna putih', 'earphone', 'earphone', 'earphone awei 4.jpg', '13.98', '2023-11-27 17:10:12', 'true'),
(57, 'Stereo ', 'Hijau', 'earphone', 'earphone', 'earphone Stereo 1.jfif', '14.99', '2023-11-27 17:10:18', 'true'),
(58, 'Stereo ', 'Biru', 'earphone', 'earphone', 'earphone Stereo 2.jfif', '14.99', '2023-11-27 17:10:22', 'true'),
(59, 'Stereo ', 'Coklat', 'earphone', 'earphone', 'earphone Stereo 3.jfif', '14.99', '2023-11-27 17:10:49', 'true'),
(60, 'Stereo ', 'Putih', 'earphone', 'earphone', 'earphone Stereo 4.jfif', '14.99', '2023-11-27 17:10:54', 'true'),
(61, 'Apple ', 'Putih', 'earphone', 'earphone', 'earphone awei 2.jfif', '59.99', '2023-11-27 17:10:59', 'true'),
(62, 'MCDODO HP-6120 iPhone', 'Hitam ', 'earphone', 'earphone', 'earphone iphone 1.jpg', '66.00', '2023-11-27 17:11:02', 'true'),
(63, 'G9 Gaming Earphone', 'Merah ', 'earphone', 'earphone', 'earphone gaming 1.jfif', '12.99', '2023-11-27 17:11:08', 'true'),
(64, 'Plextone G20 MARK IV', 'Hitam ', 'earphone', 'earphone', 'earphone gaming 2.jfif', '49.99', '2023-11-27 17:11:14', 'true'),
(65, 'Speaker Zee Cool R010A ', 'Teknologi kesambungan : USB, warna biru', 'speaker ', 'wired', 'speaker Zee 1.JPG', '7.99', '2023-11-27 17:11:18', 'true'),
(66, 'Speaker Zee Cool R010A', 'Teknologi kesambungan : USB, warna pink  ', 'speaker ', 'wired', 'speaker Zee 2.JPG', '7.99', '2023-11-27 17:11:22', 'true'),
(67, 'Speaker Zee Cool R010A', 'Teknologi kesambungan : USB, warna merah ', 'speaker ', 'wired', 'speaker Zee 3.JPG', '13.99', '2023-11-27 17:11:27', 'true'),
(68, 'Speaker Zee Cool R010A', 'Teknologi kesambungan : USB, warna putih ', 'speaker ', 'wired', 'speaker Zee 4.JPG', '7.99', '2023-11-27 17:11:31', 'true'),
(69, 'FANTECH Sonar GS203', 'Teknologi kesambungan : Kabel AUX, warna hitam ', 'speaker ', 'wired', 'speaker fantech 1.png', '89.99', '2023-11-28 14:56:55', 'true'),
(70, 'FANTECH Sonar GS203', 'Teknologi kesambungan : Kabel AUX, warna putih', 'speaker ', 'wired', 'speaker fantech 2.JPG', '89.99', '2023-11-27 17:11:39', 'true'),
(71, 'Creative Pebble 2.0', 'Teknologi kesambungan : USB, warna hitam ', 'speaker ', 'wired', 'speaker creative 1.jfif', '90.00', '2023-11-27 17:11:44', 'true'),
(72, 'Creative Pebble 2.0', 'Teknologi kesambungan : USB, warna putih ', 'speaker ', 'wired', 'speaker creative 2.jfif', '90.00', '2023-11-27 17:11:48', 'true'),
(73, 'SonicGear Sonic Cube  2.0', 'Teknologi kesambungan : USB, warna hitam ', 'speaker ', 'wired', 'speaker Sonic 1.jfif', '15.00', '2023-11-27 17:10:43', 'true'),
(74, 'SonicGear Sonic Cube  2.0', 'Teknologi kesambungan : USB, warna mint', 'speaker ', 'wired', 'speaker Sonic 2.jfif', '15.00', '2023-11-27 17:10:39', 'true'),
(75, 'SonicGear Sonic Cube  2.0', 'Teknologi kesambungan : USB, warna peach', 'speaker ', 'wired', 'speaker Sonic 3.jfif', '15.00', '2023-11-27 17:10:36', 'true'),
(76, 'SonicGear Sonic Cube  2.0', 'Teknologi kesambungan : USB, warna putih', 'speaker ', 'wired', 'speaker Sonic 4.jfif', '15.00', '2023-11-27 17:10:27', 'true'),
(77, 'Salpido Macchi 7', 'Teknologi kesambungan : USB, warna biru', 'speaker ', 'wired', 'speaker Salpido 1.JPG', '39.99', '2023-11-27 17:10:32', 'true'),
(78, 'Salpido Macchi 7', 'Teknologi kesambungan : USB, warna merah', 'speaker ', 'wired', 'speaker Salpido 2.JPG', '39.99', '2023-11-27 17:09:31', 'true'),
(79, 'Salpido Macchi 7', 'Teknologi kesambungan : USB, warna kuning', 'speaker ', 'wired', 'speaker Salpido 3.JPG', '39.99', '2023-11-27 17:09:26', 'true'),
(80, 'Salpido Macchi 7', 'Teknologi kesambungan : USB, warna hijau', 'speaker ', 'wired', 'speaker Salpido 4.JPG', '39.99', '2023-11-27 17:09:23', 'true'),
(81, 'Micro USB OLAF', 'Hitam ', 'cable & charges ', 'micro', 'cable micro olaf 1.jfif', '16.05', '2023-11-27 17:09:19', 'true'),
(82, 'Micro USB OLAF', 'Putih', 'cable & charges ', 'micro', 'cable micro olaf 2.jfif', '16.05', '2023-11-27 17:08:05', 'true'),
(83, 'Micro USB OLAF', 'Biru ', 'cable & charges ', 'micro', 'cable micro olaf 3.jfif', '16.05', '2023-11-27 17:07:59', 'true'),
(84, 'Micro USB OLAF', 'HIjau ', 'cable & charges ', 'micro', 'cable micro olaf 4.jfif', '16.05', '2023-11-27 17:07:54', 'true'),
(85, 'Pineng PN303 Micro', 'Hitam ', 'cable & charges ', 'micro', 'cable micro pineng 1.jfif', '8.00', '2023-11-27 17:07:49', 'true'),
(86, 'Pineng PN303 Micro', 'Putih', 'cable & charges ', 'micro', 'cable micro pineng 2.jfif', '8.00', '2023-11-27 17:07:45', 'true'),
(87, 'Pineng PN303 Micro', 'Merah', 'cable & charges ', 'micro', 'cable micro pineng 3.jfif', '8.00', '2023-11-27 17:07:41', 'true'),
(88, 'Pineng PN303 Micro', 'Biru', 'cable & charges ', 'micro', 'cable micro pineng 4.jfif', '8.00', '2023-11-27 17:07:38', 'true'),
(99, 'RAPA DG1015 LINE X ', 'Hitam ', 'cable & charges ', 'micro', 'cable micro rapa 1.webp', '20.00', '2023-11-27 17:07:33', 'true'),
(100, 'RAPA DG1015 LINE X ', 'Ungu', 'cable & charges ', 'micro', 'cable micro rapa 2.webp', '20.00', '2023-11-27 17:06:46', 'true'),
(101, 'RAPA DG1015 LINE X ', 'Biru Kehijauan ', 'cable & charges ', 'micro', 'cable micro rapa 3.webp', '20.00', '2023-11-27 17:06:42', 'true'),
(102, 'RAPA DG1015 LINE X ', 'Pink', 'cable & charges ', 'micro', 'cable micro rapa 4.webp', '20.00', '2023-11-27 17:06:38', 'true'),
(103, '120W 6A Super Fast', 'Putih', 'cable & charges ', 'micro', 'cable micro 6A 1.jfif', '22.00', '2023-11-27 17:06:24', 'true'),
(104, '120W 6A Super Fast', 'biru muda', 'cable & charges ', 'micro', 'cable micro 6A 2.jfif', '22.00', '2023-11-27 17:06:20', 'true'),
(105, '120W 6A Super Fast', 'Oren ', 'cable & charges ', 'micro', 'cable micro 6A 3.jpg', '22.00', '2023-11-27 17:06:16', 'true'),
(106, '120W 6A Super Fast', 'Hitam', 'cable & charges ', 'micro', 'cable micro 6A 4.jpg', '22.00', '2023-11-27 17:06:11', 'true'),
(107, 'Candy Colors Cord Fast Charging Cable', 'Kuning', 'cable & charges ', 'iphone', 'cable Candy 3.jfif', '4.00', '2023-11-28 02:43:45', 'true'),
(108, '120W Type C Cable', 'Biru ', 'cable & charges ', 'type-c', 'cable type c 120W 1.jpg', '25.00', '2023-11-27 17:12:00', 'true'),
(109, '120W Type C Cable', 'Oren ', 'cable & charges ', 'type-c', 'cable type c 120W 2.webp', '25.00', '2023-11-27 17:12:03', 'true'),
(110, 'Realme', 'Kuning ', 'cable & charges ', 'type-c', 'cable type c realmi 1.jpg', '159.00', '2023-11-28 04:45:41', 'true'),
(111, 'Realme ', 'Kuning', 'cable & charges ', 'type-c', 'cable type c realmi 2.jfif', '159.00', '2023-11-27 17:05:11', 'true'),
(112, 'Aukey CB-MCC101', 'Hitam ', 'cable & charges ', 'type-c', 'cable type c aukey 1.webp', '59.00', '2023-11-27 17:05:07', 'true'),
(113, 'Aukey CB-MCC101', 'Putih', 'cable & charges ', 'type-c', 'cable type c aukey 2.webp', '59.00', '2023-11-27 17:05:03', 'true'),
(114, 'Xiaomi ', 'Hitam ', 'cable & charges ', 'type-c', 'cable type c xioami 1.jpg', '60.00', '2023-11-27 17:05:00', 'true'),
(115, 'Xiaomi ', 'Putih ', 'cable & charges ', 'type-c', 'cable type c xioami 2.jpg', '60.00', '2023-11-27 17:04:56', 'true'),
(116, 'IKEA', 'Biru', 'cable & charges ', 'type-c', 'cable type c ikea 1.JPG', '20.00', '2023-11-27 17:04:51', 'true'),
(117, 'IKEA', 'Kuning ', 'cable & charges ', 'type-c', 'cable type c ikea 2.jpg', '20.00', '2023-11-27 17:04:46', 'true'),
(118, 'Cable Nylon Braided', 'Hitam ', 'cable & charges ', 'type-c', 'cable type c nylon 1.JPG', '10.00', '2023-11-27 17:04:42', 'true'),
(119, 'Cable Nylon Braided', 'Oren ', 'cable & charges ', 'type-c', 'cable type c nylon 2.JPG', '10.00', '2023-11-27 17:04:37', 'true'),
(120, 'Cable Nylon Braided', 'Biru', 'cable & charges ', 'type-c', 'cable type c nylon 2.jfif', '10.00', '2023-11-27 17:04:33', 'true'),
(121, 'Cable Olaf 5A', 'Biru ', 'cable & charges ', 'type-c', 'cable type c olaf 1.webp', '42.82', '2023-11-27 17:04:28', 'true'),
(122, 'Cable Olaf 5A', 'Hitam ', 'cable & charges ', 'type-c', 'cable type c olaf 2.JPG', '42.82', '2023-11-27 17:04:24', 'true'),
(123, 'Huawei ', 'Putih', 'cable & charges ', 'charger', 'charger huawei 1.jfif', '20.00', '2023-11-27 17:04:19', 'true'),
(124, 'Huawei ', 'Putih', 'cable & charges ', 'charger', 'charger huawei 2.jpg', '25.00', '2023-11-27 17:04:15', 'true'),
(125, 'iPhone ', 'Putih', 'cable & charges ', 'charger', 'changer iphone 1.jfif', '99.00', '2023-11-28 13:06:10', 'true'),
(126, 'iPhone ', 'Putih', 'cable & charges ', 'charger', 'charger iphone 2.jpg', '9.00', '2023-11-27 17:04:01', 'true'),
(127, 'Oppo', 'Putih', 'cable & charges ', 'charger', 'charger oppo 1.jfif', '25.00', '2023-11-27 17:03:58', 'true'),
(129, 'Oppo', 'Putih', 'cable & charges ', 'charger', 'charger oppo 2.jpg', '20.00', '2023-11-27 17:03:52', 'true'),
(130, 'Samsung ', 'Putih ', 'cable & charges ', 'charger', 'changer samsung 2.jfif', '90.30', '2023-11-27 17:03:49', 'true'),
(131, 'Samsung ', 'Hitam', 'cable & charges ', 'charger', 'changer samsung 1.jfif', '90.30', '2023-11-27 17:03:44', 'true'),
(132, 'Samsung ', 'Hitam', 'cable & charges ', 'charger', 'charger samsung 5.webp', '125.00', '2023-11-27 17:03:39', 'true'),
(133, 'Samsung ', 'Putih ', 'cable & charges ', 'charger', 'charger samsung 4.png', '125.00', '2023-11-27 17:03:35', 'true'),
(134, 'Vivo ', 'Putih ', 'cable & charges ', 'charger', 'charger vivo 1.png', '25.90', '2023-11-28 15:38:07', 'true'),
(136, 'Vivo ', 'Putih ', 'cable & charges ', 'charger', 'changer vivo 2.jfif', '20.00', '2023-11-27 17:03:23', 'true'),
(137, 'Xiaomi ', 'Putih', 'cable & charges ', 'charger', 'charger xioami 1.jfif', '50.00', '2023-11-27 17:03:18', 'true'),
(138, 'Xiaomi ', 'Hitam ', 'cable & charges ', 'charger', 'charger xioami 2.jfif', '50.00', '2023-11-27 17:03:14', 'true'),
(139, 'Xiaomi ', 'Hitam ', 'cable & charges ', 'charger', 'charger xioami 3.jpg', '30.00', '2023-11-27 17:03:10', 'true'),
(140, 'Xiaomi ', 'Putih ', 'cable & charges ', 'charger', 'charger xioami 3.webp', '20.00', '2023-11-27 17:03:06', 'true'),
(141, 'Cable Olaf 5A', 'Merah ', 'cable & charges ', 'type-c', 'cable type c olaf 4.JPG', '42.82', '2023-11-28 14:47:48', 'true'),
(142, 'Candy Colors Cord Fast Charging Cable', 'Hijau ', 'cable & charges ', 'iphone', 'cable Candy 1.jfif', '4.00', '2023-11-28 14:47:51', 'true'),
(143, 'Candy Colors Cord Fast Charging Cable', 'Merah ', 'cable & charges ', 'iphone', 'cable Candy 4.jfif', '4.00', '2023-11-28 15:02:58', 'true'),
(144, 'Candy Colors Cord Fast Charging Cable', 'Ungu', 'cable & charges ', 'iphone', 'cable Candy 2.jfif', '4.00', '2023-11-28 15:03:19', 'true'),
(145, 'REMAX', 'Merah', 'cable & charges ', 'iphone', 'cable remax iphone 1.webp', '25.00', '2023-11-28 15:04:02', 'true'),
(146, 'REMAX ', 'Hitam ', 'cable & charges ', 'iphone', 'cable remax iphone 2.webp', '25.00', '2023-11-28 15:04:05', 'true'),
(147, 'REMAX', 'Putih  ', 'cable & charges ', 'iphone', 'cable remax iphone 3.webp', '25.00', '2023-11-28 15:04:08', 'true'),
(148, 'REMAX', 'Biru', 'cable & charges ', 'iphone', 'cable remax iphone 4.webp', '25.00', '2023-11-28 15:04:12', 'true'),
(149, 'MCDODO CA 1910', 'Pink', 'cable & charges ', 'iphone', 'cable mcdodo iphone 2.jpg', '20.00', '2023-11-28 15:04:37', 'true'),
(150, 'MCDODO CA 1910', 'Ungu', 'cable & charges ', 'iphone', 'cable mcdodo iphone 1.jpg', '20.00', '2023-11-28 15:04:44', 'true'),
(151, 'BASEUS ', 'Merah ', 'cable & charges ', 'iphone', 'cable baseus iphone 2.webp', '23.80', '2023-11-28 15:04:56', 'true'),
(152, 'BASEUS ', 'Biru  ', 'cable & charges ', 'iphone', 'cable baseus iphone 3.webp', '23.80', '2023-11-28 15:05:01', 'true'),
(153, 'BASEUS ', 'Hitam ', 'cable & charges ', 'iphone', 'cable baseus iphone 1.webp', '23.80', '2023-11-28 15:05:05', 'true'),
(154, 'UGREEN ', 'Hitam ', 'cable & charges ', 'iphone', 'Cable ungreen iphone 3.webp', '42.98', '2023-11-28 15:05:32', 'true'),
(155, 'UGREEN ', 'Putih', 'cable & charges ', 'iphone', 'Cable ungreen iphone 2.jpg', '42.98', '2023-11-28 15:05:36', 'true'),
(156, 'UGREEN ', 'Kelabu pekat ', 'cable & charges ', 'iphone', 'Cable ungreen iphone 1.jfif', '42.98', '2023-11-28 15:05:41', 'true');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `butiran_troli`
--
ALTER TABLE `butiran_troli`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_pengguna`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `butiran_troli`
--
ALTER TABLE `butiran_troli`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_pengguna` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2187;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
