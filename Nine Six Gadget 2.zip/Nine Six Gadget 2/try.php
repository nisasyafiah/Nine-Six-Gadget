<?php
include('config.php');
include('common_function.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NINE SIX GADGET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer">
    <link rel="stylesheet" href="style3.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
</head>
<body>
  <br>
<div class="container">
  <div class="row">
    <table class="table table-bordered text-center">
      <thead>
        <tr>
          <th>product</th>
          <th>images</th>
          <th>ulasan</th>
          <th>harga</th>
          <th>quantity</th>
          <th>remove</th>
          <th colspan="2">operation</th>
        </tr>
      </thead>
      <tbody>
        <?php
          global $con;
          $get_ip_add=getIPAddress();
          $total_price=0;
          $cart_query="Select * from `butiran_troli` where ip_address='$get_ip_add'";
          $result=mysqli_query($con,$cart_query);
          while($row=mysqli_fetch_array($result)){
            $id_produk=$row['id_produk'];
            $select_products="Select*from `produk` where id_produk='$id_produk'";
            $result_products=mysqli_query($con,$select_products);
            while($row_product_price=mysqli_fetch_array($result_products)){
              $harga_produk=array($row_product_price['harga_produk']);
              $price_table=$row_product_price['harga_produk'];
              $nama_produk=$row_product_price['nama_produk'];
              $ulasan_produk=$row_product_price['ulasan_produk'];
              $gambar_produk=$row_product_price['gambar_produk'];
              $product_values=array_sum($harga_produk);
              $total_price+=$product_values;
        ?>
        <tr>
          <td><?php echo $nama_produk?></td>
          <td><?php echo $ulasan_produk?></td>
          <td><img src="gambar_produkk/<?php echo $gambar_produk?>" width="30%" alt=""></td>
          <td>RM: <?php echo $price_table?></td>
          <td><input type="text" name="" id="" class="form-input w-50"></td>
          <td><input type="checkbox"></td>
          <td>
            <button>Update</button><button>Remove</button>
          </td>
        </tr>
        <?php
        }
      }
        ?>
      </tbody>
    </table>

    <div class="d-flex mb-5">
      <h4 class="px-3">subtotal <strong class="text-info">RM: <?php echo $total_price?></strong></h4>
      <a href="headphone.php"><button class="bg-info px-3 py-2 border-0 mx-3">Continue Shopping</button></a>
      <a href="#"><button class="bg-secondary px-3 py-2 border-0 text-light">Checkout </button></a>
    </div>
    <br>
  </div>
</div>
</body>
</html>

