<?php
include('config.php');
include('common_function.php');
?>
<?php
$id_pengguna = 6;

// Fetch user information from the database
$user_query = "SELECT * FROM pengguna WHERE id_pengguna = $id_pengguna";
$user_result = mysqli_query($con, $user_query);
$user_data = mysqli_fetch_assoc($user_result);

// Check if user data is found
if ($user_data) {
    $nama_pengguna = $user_data['nama_pengguna'];
    $email_pengguna = $user_data['email_pengguna'];
    $notel_pengguna = $user_data['notel_pengguna'];
} else {
    // Handle the case when user data is not found
    // You can redirect or display an error message
    echo "User not found";
    exit;
}
?>
<?php
//payment-ebook-generate-gateway-call.php

$totalprice=$_POST['totalprice'];
//insert POST data ke tblorder
//$qinsorder=sqlquery("insert into tblorder (nama, email, telefon,harga, status, tarikh) values (?,?,?,?,?,now())");
//$qinsorder->bindValue(1,$nama);
//$qinsorder->bindValue(2,$email);
//$qinsorder->bindValue(3,$telefon);
//$qinsorder->bindValue(4,$harga);
//$qinsorder->bindValue(5,0);
//$qinsorder->execute();
//get orderid
//$qgetoid=sqlquery("select id from tblorder order by id desc limit 1");
//$qgetoid->execute();
//$getoid = $qgetoid->fetch(PDO::FETCH_ASSOC);
//$oid=$getoid['id']; 
//convert RM1=100
$rmx100=($totalprice*100);
$some_data = array(
    'userSecretKey'=> '1u9a1f7l-8tzd-qi9q-0yyy-6yfbksjx0utn',
    'categoryCode'=> 'yxrpnj2g',
    'billName'=> 'Pembelian di Nine Six Gadget',
    'billDescription'=> 'Belian aksesori gajet sebanyak RM'.$totalprice,
    'billPriceSetting'=>1,
    'billPayorInfo'=>1,
    'billAmount'=>$rmx100,
    'billReturnUrl'=>'index.php',
    'billCallbackUrl'=>'',
    'billExternalReferenceNo'=>'',
    'billTo'=>$nama_pengguna,
    'billEmail'=>$email_pengguna,
    'billPhone'=>$notel_pengguna,
    'billSplitPayment'=>0,
    'billSplitPaymentArgs'=>'',
    'billPaymentChannel'=>0,
  );  
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_POST, 1);
  curl_setopt($curl, CURLOPT_URL, 'https://toyyibpay.com/index.php/api/createBill');  
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $some_data);
  $result = curl_exec($curl);
  $info = curl_getinfo($curl);  
  curl_close($curl);
  $obj = json_decode($result,true);
  $billcode=$obj[0]['BillCode'];
?>
<!--SEND USER TO TOYYIBPAY PAYMENT-->
<script type="text/javascript">
    //redirect to payment gateway
   window.location.href="https://toyyibpay.com/<?php echo $billcode;?>"; 
 </script>