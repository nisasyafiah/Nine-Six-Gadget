<?php
$con=mysqli_connect('localhost','root','','sistem_gajet');
if(!$con){
    die(mysqli_error($con));
}
?>