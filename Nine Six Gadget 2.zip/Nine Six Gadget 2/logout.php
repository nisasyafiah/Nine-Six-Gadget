<?php

session_start();
sesssion_unset();
session_destroy();

?>