<?php
include('config.php');
include('common_function.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NINE SIX GADGET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style3.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    <style>
      .gradient-custom {
  /* fallback for old browsers */
  background: #202020;
  
  /* Chrome 10-25, Safari 5.1-6 */
  background: -webkit-linear-gradient(to right, rgb(0, 0, 0), rgb(98, 99, 99));
  
  /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
  background: linear-gradient(to right, rgb(0, 0, 0), rgb(95, 96, 97))
  }
    </style>
</head>
<body  class="h-100 gradient-custom">
    <br>
    <div class="mx-auto p-2" style="width: 20%;">
      <img src="NSG_Logo.png" class="rounded" alt="..." width="100%">
</div>
<form action="" method="post" enctype="multipart/form-data">
<div class="mx-auto p-2" style="width: 50%;">

<!--nama_pengguna-->
  <div class="mb-3">
    <label for="nama_pengguna" class="form-label text-white">Nama </label>
    <input type="text" class="form-control" id="nama_pengguna" placeholder="Masukkan Nama" required="required" name="nama_pengguna">
  </div>

<!--email_pengguna-->
<div class="mb-3">
    <label for="email_pengguna" class="form-label text-white">Emel </label>
    <input type="text" class="form-control" id="email_pengguna" placeholder="Masukkan Email" required="required" name="email_pengguna">
  </div>

<!--katalaluan_pengguna-->
  <div class="mb-3">
    <label for="katalaluan_pengguna" class="form-label text-white">Kata Laluan</label>
    <input type="password" class="form-control" id="katalaluan_pengguna" placeholder="Masukkan Kata Laluan" required="required" name="katalaluan_pengguna">
  </div>
 
<!--confirm_password-->
<div class="mb-3">
    <label for="sahkatalaluan_pengguna" class="form-label text-white">Sahkan Kata Laluan </label>
    <input type="password" class="form-control" id="sahkatalaluan_pengguna" placeholder="Sahkan Kata Laluan" required="required" name="sahkatalaluan_pengguna">
  </div>

<!--notel_pengguna-->
<div class="mb-3">
    <label for="notel_pengguna" class="form-label text-white">Nombor Telefon</label>
    <input type="text" class="form-control" id="notel_pengguna" placeholder="Masukkan Nombor Telefon" required="required" name="notel_pengguna">
  </div>  

  <button type="submit" Value="Daftar Akaun" class="btn btn-primary " name="user_register">Daftar Akaun</button>
<p class="text-white">Sudah mempunyai akaun? <a href="user_login.php" class="fw-bold">Log Masuk</a></p>
</form>
  </div>
</body>
</html>
 
<!--php code-->
<?php
if(isset($_POST['user_register'])){
    $nama_pengguna=$_POST['nama_pengguna'];
    $email_pengguna=$_POST['email_pengguna'];
    $katalaluan_pengguna=$_POST['katalaluan_pengguna'];
    $hash_password=password_hash($katalaluan_pengguna,PASSWORD_DEFAULT);
    $sahkatalaluan_pengguna=$_POST['sahkatalaluan_pengguna'];
    $notel_pengguna=$_POST['notel_pengguna']; 
    $gambar_pengguna=$_FILES['gambar_pengguna']['name'];
    $gambar_pengguna_tmp=$_FILES['gambar_pengguna']['tmp_name'];
    $ip_pengguna=getIPAddress();

    //select query
    $select_query="Select*from `pengguna` where nama_pengguna='$nama_pengguna' or email_pengguna='$email_pengguna'";
    $result=mysqli_query($con,$select_query);
    $rows_count=mysqli_num_rows($result);
    if($rows_count>0){
        echo "<script>alert('Nama dan email telah digunakan')</script>";
    }else if($katalaluan_pengguna!=$sahkatalaluan_pengguna){
        echo "<script>alert('Password not match')</script>";
    }else{
       //insert query
    move_uploaded_file($gambar_pengguna_tmp,"gambar_penggunaa/$gambar_pengguna");
    $insert_query="insert into `pengguna` (nama_pengguna, email_pengguna, katalaluan_pengguna, gambar_pengguna, ip_pengguna, notel_pengguna) values ('$nama_pengguna','$email_pengguna','$hash_password','$gambar_pengguna','$ip_pengguna','$notel_pengguna')";
    $sql_execute=mysqli_query($con,$insert_query);
   
    if($sql_execute){
        echo"<script>alert('Daftar Akaun Berjaya')</script>";
    }

    //selecting cart items
    $select_cart_items="Select * from `butiran_troli` where ip_address='$ip_pengguna'";
    $result_cart=mysqli_query($con,$select_cart_items);
    $rows_count=mysqli_num_rows($result_cart);
    if($rows_count>0){
        $_SESSION['nama_pengguna']=$nama_pengguna;
        echo "<script>alert('Anda mempunyai barang di troli')</script>";
        echo "<script>window.open('cart.php','_self')</script>";
    }else{
        echo "<script>window.open('index.php','_self')</script>";
    }}
    
}
?>