<?php
include('config.php');

//getting headphone product
function getheadphone(){
    global $con;
    $select_query="Select * from `produk` WHERE kategori_produk='headphone'";
$result_query=mysqli_query($con, $select_query);
//$row=mysqli_fetch_assoc($result_query);
//echo $row['nama_produk'];
while($row=mysqli_fetch_assoc($result_query)){
  $id_produk=$row['id_produk'];
  $nama_produk=$row['nama_produk'];
  $ulasan_produk=$row['ulasan_produk'];
  $katakunci_produk=$row['katakunci_produk'];
  $kategori_produk=$row['kategori_produk'];
  $gambar_produk=$row['gambar_produk'];
  $harga_produk=$row['harga_produk'];
  echo "<div class='col-md-3 mb-4'>
<div class='card'>
<img src='./gambar_produkk/$gambar_produk' class='card-img-top w-75 mx-auto' alt=...'>
<div class='card-body card-bg'>
  <h5 class='card-title'>$nama_produk</h5>
  <p class='card-text'>Ulasan: $ulasan_produk</p>
  <p class='card-text'>Harga: RM $harga_produk</p>
  <a href='headphone.php?add_to_cart=$id_produk' class='btn btn-primary btn-sm'>Tambah Ke Troli</a>
</div>
</div>
</div>
";
}
}

//getting earphone product
function getearphone(){
    global $con;
    $select_query="Select * from `produk` WHERE kategori_produk='earphone'";
$result_query=mysqli_query($con, $select_query);
//$row=mysqli_fetch_assoc($result_query);
//echo $row['nama_produk'];
while($row=mysqli_fetch_assoc($result_query)){
  $id_produk=$row['id_produk'];
  $nama_produk=$row['nama_produk'];
  $ulasan_produk=$row['ulasan_produk'];
  $katakunci_produk=$row['katakunci_produk'];
  $kategori_produk=$row['kategori_produk'];
  $gambar_produk=$row['gambar_produk'];
  $harga_produk=$row['harga_produk'];
  echo "<div class='col-md-3 mb-4'>
<div class='card'>
<img src='./gambar_produkk/$gambar_produk' class='card-img-top w-75 mx-auto' alt=...'>
<div class='card-body card-bg'>
  <h5 class='card-title'>$nama_produk</h5>
  <p class='card-text'>Ulasan: $ulasan_produk</p>
  <p class='card-text'>Harga: RM $harga_produk</p>
  <a href='headphone.php?add_to_cart=$id_produk' class='btn btn-primary btn-sm'>Tambah Ke Troli</a>
</div>
</div>
</div>
";
}
}

//getting earbud product
function getearbud(){
    global $con;
    $select_query="Select * from `produk` WHERE kategori_produk='earbud'";
$result_query=mysqli_query($con, $select_query);
//$row=mysqli_fetch_assoc($result_query);
//echo $row['nama_produk'];
while($row=mysqli_fetch_assoc($result_query)){
  $id_produk=$row['id_produk'];
  $nama_produk=$row['nama_produk'];
  $ulasan_produk=$row['ulasan_produk'];
  $katakunci_produk=$row['katakunci_produk'];
  $kategori_produk=$row['kategori_produk'];
  $gambar_produk=$row['gambar_produk'];
  $harga_produk=$row['harga_produk'];
  echo "<div class='col-md-3 mb-4'>
<div class='card'>
<img src='./gambar_produkk/$gambar_produk' class='card-img-top w-75 mx-auto' alt=...'>
<div class='card-body card-bg'>
  <h5 class='card-title'>$nama_produk</h5>
  <p class='card-text'>Ulasan: $ulasan_produk</p>
  <p class='card-text'>Harga: RM $harga_produk</p>
  <a href='headphone.php?add_to_cart=$id_produk' class='btn btn-primary btn-sm'>Tambah Ke Trolit</a>
</div>
</div>
</div>
";
}
}

//getting wireless product
function getwireless(){
    global $con;
    $select_query="Select * from `produk` WHERE kategori_produk='wireless'";
$result_query=mysqli_query($con, $select_query);
//$row=mysqli_fetch_assoc($result_query);
//echo $row['nama_produk'];
while($row=mysqli_fetch_assoc($result_query)){
  $id_produk=$row['id_produk'];
  $nama_produk=$row['nama_produk'];
  $ulasan_produk=$row['ulasan_produk'];
  $katakunci_produk=$row['katakunci_produk'];
  $kategori_produk=$row['kategori_produk'];
  $gambar_produk=$row['gambar_produk'];
  $harga_produk=$row['harga_produk'];
  echo "<div class='col-md-3 mb-4'>
<div class='card'>
<img src='./gambar_produkk/$gambar_produk' class='card-img-top w-75 mx-auto' alt=...'>
<div class='card-body card-bg'>
  <h5 class='card-title'>$nama_produk</h5>
  <p class='card-text'>Ulasan: $ulasan_produk</p>
  <p class='card-text'>Harga: RM $harga_produk</p>
  <a href='headphone.php?add_to_cart=$id_produk' class='btn btn-primary btn-sm'>Tambah Ke Troli</a>
</div>
</div>
</div>
";
}
}

//getting wired product
function getwired(){
    global $con;
    $select_query="Select * from `produk` WHERE kategori_produk='wired'";
$result_query=mysqli_query($con, $select_query);
//$row=mysqli_fetch_assoc($result_query);
//echo $row['nama_produk'];
while($row=mysqli_fetch_assoc($result_query)){
  $id_produk=$row['id_produk'];
  $nama_produk=$row['nama_produk'];
  $ulasan_produk=$row['ulasan_produk'];
  $katakunci_produk=$row['katakunci_produk'];
  $kategori_produk=$row['kategori_produk'];
  $gambar_produk=$row['gambar_produk'];
  $harga_produk=$row['harga_produk'];
  echo "<div class='col-md-3 mb-4'>
<div class='card'>
<img src='./gambar_produkk/$gambar_produk' class='card-img-top w-75 mx-auto' alt=...'>
<div class='card-body card-bg'>
  <h5 class='card-title'>$nama_produk</h5>
  <p class='card-text'>Ulasan: $ulasan_produk</p>
  <p class='card-text'>Harga: RM $harga_produk</p>
  <a href='headphone.php?add_to_cart=$id_produk' class='btn btn-primary btn-sm'>Tambah Ke Troli</a>
</div>
</div>
</div>
";
}
}

//getting micro product
function getmicro(){
    global $con;
    $select_query="Select * from `produk` WHERE kategori_produk='micro'";
$result_query=mysqli_query($con, $select_query);
//$row=mysqli_fetch_assoc($result_query);
//echo $row['nama_produk'];
while($row=mysqli_fetch_assoc($result_query)){
  $id_produk=$row['id_produk'];
  $nama_produk=$row['nama_produk'];
  $ulasan_produk=$row['ulasan_produk'];
  $katakunci_produk=$row['katakunci_produk'];
  $kategori_produk=$row['kategori_produk'];
  $gambar_produk=$row['gambar_produk'];
  $harga_produk=$row['harga_produk'];
  echo "<div class='col-md-3 mb-4'>
<div class='card'>
<img src='./gambar_produkk/$gambar_produk' class='card-img-top w-75 mx-auto' alt=...'>
<div class='card-body card-bg'>
  <h5 class='card-title'>$nama_produk</h5>
  <p class='card-text'>Ulasan: $ulasan_produk</p>
  <p class='card-text'>Harga: RM $harga_produk</p>
  <a href='headphone.php?add_to_cart=$id_produk' class='btn btn-primary btn-sm'>Tambah Ke Troli</a>
</div>
</div>
</div>
";
}
}

//getting type-c product
function gettypec(){
    global $con;
    $select_query="Select * from `produk` WHERE kategori_produk='type-c'";
$result_query=mysqli_query($con, $select_query);
//$row=mysqli_fetch_assoc($result_query);
//echo $row['nama_produk'];
while($row=mysqli_fetch_assoc($result_query)){
  $id_produk=$row['id_produk'];
  $nama_produk=$row['nama_produk'];
  $ulasan_produk=$row['ulasan_produk'];
  $katakunci_produk=$row['katakunci_produk'];
  $kategori_produk=$row['kategori_produk'];
  $gambar_produk=$row['gambar_produk'];
  $harga_produk=$row['harga_produk'];
  echo "<div class='col-md-3 mb-4'>
<div class='card'>
<img src='./gambar_produkk/$gambar_produk' class='card-img-top w-75 mx-auto' alt=...'>
<div class='card-body card-bg'>
  <h5 class='card-title'>$nama_produk</h5>
  <p class='card-text'>Ulasan: $ulasan_produk</p>
  <p class='card-text'>Harga: RM $harga_produk</p>
  <a href='headphone.php?add_to_cart=$id_produk' class='btn btn-primary btn-sm'>Tambah Ke Troli</a>
</div>
</div>
</div>
";
}
}

//getting iphone product
function getiphone(){
  global $con;
  $select_query="Select * from `produk` WHERE kategori_produk='iphone'";
$result_query=mysqli_query($con, $select_query);
//$row=mysqli_fetch_assoc($result_query);
//echo $row['nama_produk'];
while($row=mysqli_fetch_assoc($result_query)){
$id_produk=$row['id_produk'];
$nama_produk=$row['nama_produk'];
$ulasan_produk=$row['ulasan_produk'];
$katakunci_produk=$row['katakunci_produk'];
$kategori_produk=$row['kategori_produk'];
$gambar_produk=$row['gambar_produk'];
$harga_produk=$row['harga_produk'];
echo "<div class='col-md-3 mb-4'>
<div class='card'>
<img src='./gambar_produkk/$gambar_produk' class='card-img-top w-75 mx-auto' alt='Product Image'>
<div class='card-body card-bg'>
<h5 class='card-title'>$nama_produk</h5>
<p class='card-text'>Ulasan: $ulasan_produk</p>
<p class='card-text'>Harga: RM $harga_produk</p>
<a href='iphone.php?add_to_cart=$id_produk' class='btn btn-primary btn-sm'>Tambah Ke Troli</a>
</div>
</div>
</div>
";
}
}

// getting charger product
function getCharger() {
  global $con;
  $select_query = "SELECT * FROM `produk` WHERE kategori_produk='charger'";
  $result_query = mysqli_query($con, $select_query);

  while ($row = mysqli_fetch_assoc($result_query)) {
      $id_produk = $row['id_produk'];
      $nama_produk = $row['nama_produk'];
      $ulasan_produk = $row['ulasan_produk'];
      $katakunci_produk = $row['katakunci_produk'];
      $kategori_produk = $row['kategori_produk'];
      $gambar_produk = $row['gambar_produk'];
      $harga_produk = $row['harga_produk'];

      echo "
      <div class='col-md-3 mb-4'>
          <div class='card'>
              <img src='./gambar_produkk/$gambar_produk' class='card-img-top w-75 mx-auto' alt='Product Image'>
              <div class='card-body card-bg'>
                  <h5 class='card-title'>$nama_produk</h5>
                  <p class='card-text'>Ulasan: $ulasan_produk</p>
                  <p class='card-text'>Harga: RM $harga_produk</p>
                  <a href='charger.php?add_to_cart=$id_produk' class='btn btn-primary btn-sm'>Tambah Ke Troli</a>
              </div>
          </div>
      </div>
      ";
  }
}



//get ip address function
    function getIPAddress() {  
    //whether ip is from the share internet  
     if(!empty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    //whether ip is from the proxy  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
//$ip = getIPAddress();  
//echo 'User Real IP Address - '.$ip;  

//cart function
function cart(){
  if(isset($_GET['add_to_cart'])){
    global $con;
    $get_ip_add = getIPAddress();
    $get_product_id=$_GET['add_to_cart'];
    $select_query="Select*from `butiran_troli` where ip_address='$get_ip_add' and id_produk=$get_product_id";
    $result_query=mysqli_query($con, $select_query);
    $num_of_rows=mysqli_num_rows($result_query);
    if($num_of_rows>0){
      // echo "ada";
      echo"<script>alert('Produk telah dimasukkan')</script>";
      echo"<script>window.open('headphone.php','_self')</script>";
    }else{
      // echo "tiada";
      $insert_query="insert into `butiran_troli` values ('$get_product_id','$get_ip_add',0)";
      $result_query=mysqli_query($con, $insert_query);
      echo"<script>('Item is added to cart')</script>";
      echo"<script>window.open('headphone.php','_self')</script>";
    }
  }
  }

  //function to get cart item numbers
  function cart_item(){
    if(isset($_GET['add_to_cart'])){
      global $con;
      $get_ip_add = getIPAddress();
      $select_query="Select*from `butiran_troli` where ip_address='$get_ip_add'";
      $result_query=mysqli_query($con, $select_query);
      $count_cart_items=mysqli_num_rows($result_query);
      }else{
        global $con;
        $get_ip_add = getIPAddress();
        $select_query="Select*from `butiran_troli` where ip_address='$get_ip_add'";
        $result_query=mysqli_query($con, $select_query);
        $count_cart_items=mysqli_num_rows($result_query);
      }
      echo $count_cart_items;
    }

    //total price function
    function total_cart_price(){
      global $con;
      $get_ip_add=getIPAddress();
      $total_price=0;
      $cart_query="Select * from `butiran_troli` where ip_address='$get_ip_add'";
      $result=mysqli_query($con,$cart_query);
      while($row=mysqli_fetch_array($result)){
        $id_produk=$row['id_produk'];
        $select_products="Select*from `produk` where id_produk='$id_produk'";
        $result_products=mysqli_query($con,$select_products);
        while($row_product_price=mysqli_fetch_array($result_products)){
          $harga_produk=array($row_product_price['harga_produk']);
          $product_values=array_sum($harga_produk);
          $total_price+=$product_values;
      }
    }
    echo $total_price;
  }
?> 