<?php
include('config.php');
include('common_function.php');
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NINE SIX GADGET</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
  </head>
  <body>
    <?php
    search_product();
    ?>
  <nav class="navbar navbar-expand-lg bg-body-white header">
  <div class="container-fluid">
  <a class="navbar-brand" href="#">
      <img src="NSG_Logo.png" alt="Nine Six Gadget" width="100" height="100">
    </a>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item navbarhover">
          <a class="nav-link active " aria-current="page" href="index.php">HALAMAN UTAMA</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            HEADPHONES
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item dropdown-content" href="headphone.php">Headphone</a></li>
            <li><a class="dropdown-item dropdown-content" href="earphone.php">Earphone</a></li>
            <li><a class="dropdown-item dropdown-content" href="earbud.php">Earbud</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            SPEAKERS
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item dropdown-content" href="wireless.php">Wireless</a></li>
            <li><a class="dropdown-item dropdown-content" href="wired.php">Wired</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link active dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            CABLES & CHARGERS
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item dropdown-content" href="micro.php">Cable Micro</a></li>
            <li><a class="dropdown-item dropdown-content" href="typec.php">Cable Type-C</a></li>
            <li><a class="dropdown-item dropdown-content" href="earbud.php">Cable</a></li>
            <li><a class="dropdown-item dropdown-content" href="charger.php">Charger</a></li>
          </ul>
        </li>
      </ul>

      
      <div class="searchbar">
      <form class="d-flex" action="search_product.php" method="get">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" name="search_data">
      <input type="submit" value="Search" class="btn btn-outline-success" name="search_data_product">
      </form>
      </div>
      
      <div class="nav-item cart">
        <a class="nav-link" href="#"><i class="fa fa-shopping-cart"></i></a>
      </div>

      <div class="cart">
      <div class="nav-item ">
        <a class="nav-link" href="#"><i class="fa fa-user"></i></a>
      </div>
</div>
    </div>
  </div>
</div>
</nav>

<br>
<h1 class="text-center">Headphones</h1>
<!--products-->
<div class="row mx-auto p-5">
  
<?php
$select_query="Select * from `produk` WHERE kategori_produk='headphone'";
$result_query=mysqli_query($con, $select_query);
//$row=mysqli_fetch_assoc($result_query);
//echo $row['nama_produk'];
while($row=mysqli_fetch_assoc($result_query)){
  $id_produk=$row['id_produk'];
  $nama_produk=$row['nama_produk'];
  $ulasan_produk=$row['ulasan_produk'];
  $katakunci_produk=$row['katakunci_produk'];
  $kategori_produk=$row['kategori_produk'];
  $gambar_produk=$row['gambar_produk'];
  $harga_produk=$row['harga_produk'];
  echo "<div class='col-md-3 mb-2'>
<div class='card'>
<img src='./gambar_produkk/$gambar_produk' class='card-img-top' alt=...'>
<div class='card-body card-bg'>
  <h5 class='card-title'>$nama_produk</h5>
  <p class='card-text'>$ulasan_produk</p>
  <a href='#' class='btn btn-primary'>Add to cart</a>
  <a href='#' class='btn btn-secondary'>View more</a>
</div>
</div>
</div>
";
}
?>
</div>
    </div>
    </div>
</div>
    </div>
    </div>
</div>

  </body>
</html>