- Import sistem_gajet.sql for system database
- Open index.php for user page
- Open admin.php for admin page (username: admin, password:admin)
- The payment is fully functional, if you do a transaction, your money will go into my toyyibpay account

